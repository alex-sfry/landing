<footer class="footer">
    <div class="footer-container"><?= CFS()->get('footer_text'); ?></div>
</footer>

<?php wp_footer(); ?>

</body>

</html>